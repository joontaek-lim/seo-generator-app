import SeoGeneratorApp from "@/components/SeoGeneratorApp";

export default function Home() {
  return <SeoGeneratorApp />;
}